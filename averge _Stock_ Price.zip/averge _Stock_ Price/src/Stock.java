public class Stock {

    private int shares;
    private double price;
    private double capital;

    // Constructor
    public void buy(double p, int s){

        shares +=s;
        price = p;
        capital += s*p;
    }
    public void sell(double p, int s){
        shares -= s;
        price = p;
        capital-= s*p;
    }
    public int getShares(){
        return shares;
    }
    public double getPrice(){
        return price;
    }
    public double getAvergePrice(){
        return capital/getShares();
    }
}
