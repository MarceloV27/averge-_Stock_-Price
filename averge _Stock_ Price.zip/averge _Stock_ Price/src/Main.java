public class Main {
    public static void main(String[] args) {

        Stock myCompany = new Stock();

        myCompany.buy(53.4, 2000);
        myCompany.buy(53.4, 3000);
        myCompany.buy(53.4, 4000);

        System.out.println(myCompany.getShares());
        System.out.println(myCompany.getPrice());
        System.out.println(myCompany.getAvergePrice());




    }
}